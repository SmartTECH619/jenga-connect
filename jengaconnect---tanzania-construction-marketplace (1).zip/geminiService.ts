
import { GoogleGenAI } from "@google/genai";

// Use directly from process.env.API_KEY as per coding guidelines
const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });

export const getProjectOptimizationTips = async (title: string, description: string) => {
  try {
    const response = await ai.models.generateContent({
      model: 'gemini-3-flash-preview',
      contents: `You are a construction expert in Tanzania. Give 3 short, punchy tips to improve this project posting to attract better mafundi: Title: ${title}, Description: ${description}`,
    });
    return response.text;
  } catch (error) {
    console.error("AI Tips Error:", error);
    return "Ensure you list your specific tools required and if transport is provided.";
  }
};

export const suggestMatchingSkills = async (title: string, description: string) => {
  try {
    const response = await ai.models.generateContent({
      model: 'gemini-3-flash-preview',
      contents: `Based on this construction project in Tanzania: "${title} - ${description}", suggest a list of 3-5 specific construction skills (e.g. Masonry, Electrician) needed. Format as a comma separated list.`,
    });
    return response.text;
  } catch (error) {
    console.error("AI Skill Suggestion Error:", error);
    return "Masonry, Welder, Electrician";
  }
};
