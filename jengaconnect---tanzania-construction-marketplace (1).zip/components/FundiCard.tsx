
import React from 'react';
import { FundiProfile, User } from '../types';
import { getIconForSkill, CURRENCY, UNLOCK_FEE } from '../constants';
import { translations } from '../translations';

interface FundiCardProps {
  fundi: FundiProfile;
  user: User;
  isUnlocked: boolean;
  onUnlock: (fundiId: string) => void;
  language: 'sw' | 'en';
}

const FundiCard: React.FC<FundiCardProps> = ({ fundi, user, isUnlocked, onUnlock, language }) => {
  const t = translations[language];
  
  return (
    <div className="bg-white dark:bg-slate-900 rounded-xl shadow-sm border border-gray-200 dark:border-slate-800 overflow-hidden hover:shadow-md dark:hover:shadow-xl transition-all duration-300">
      <div className="p-5">
        <div className="flex justify-between items-start mb-4">
          <div className="flex gap-4">
            <img src={user.avatar} alt={user.name} className="w-16 h-16 rounded-full object-cover border-2 border-gray-100 dark:border-slate-800 shadow-sm" />
            <div className="min-w-0">
              <div className="flex items-center gap-2">
                <h3 className="font-bold text-gray-900 dark:text-white truncate max-w-[120px] md:max-w-full">{user.name}</h3>
                {fundi.isVerified && (
                  <span className="text-blue-500" title={t.verified}>
                    <i className="fa-solid fa-circle-check text-xs"></i>
                  </span>
                )}
              </div>
              <p className="text-sm text-gray-500 dark:text-slate-400 flex items-center gap-1">
                {getIconForSkill(fundi.skill)}
                {fundi.skill}
              </p>
              <div className="flex items-center gap-1 mt-1">
                <i className="fa-solid fa-star text-yellow-400 text-xs"></i>
                <span className="text-sm font-semibold text-gray-900 dark:text-white">{fundi.rating}</span>
                <span className="text-[10px] text-gray-400 dark:text-slate-500">({fundi.reviewCount})</span>
              </div>
            </div>
          </div>
          <span className={`px-2 py-1 rounded-full text-[10px] font-bold uppercase ${
            fundi.availability === 'Available' ? 'bg-green-100 text-green-700 dark:bg-green-900/30 dark:text-green-500' : 
            fundi.availability === 'Busy' ? 'bg-orange-100 text-orange-700 dark:bg-orange-900/30 dark:text-orange-500' : 'bg-gray-100 text-gray-700 dark:bg-slate-800 dark:text-slate-500'
          }`}>
            {fundi.availability === 'Available' ? t.available : fundi.availability === 'Busy' ? t.busy : t.offline}
          </span>
        </div>

        <div className="space-y-3 mb-4">
          <div className="flex items-center gap-2 text-sm text-gray-600 dark:text-slate-400">
            <i className="fa-solid fa-location-dot text-gray-400 dark:text-slate-600"></i>
            <span className="truncate">{fundi.location.district}, {fundi.location.region}</span>
          </div>
          <div className="flex items-center gap-2 text-sm text-gray-600 dark:text-slate-400">
            <i className="fa-solid fa-briefcase text-gray-400 dark:text-slate-600"></i>
            <span>{fundi.experienceYears} {t.years} {t.experience}</span>
          </div>
          <p className="text-sm text-gray-600 dark:text-slate-400 line-clamp-2 italic">{fundi.bio}</p>
        </div>

        <div className="flex gap-2 overflow-x-auto pb-2 no-scrollbar">
          {fundi.portfolio.slice(0, 3).map((img, idx) => (
            <img key={idx} src={img} className="w-20 h-20 rounded-lg object-cover flex-shrink-0 border border-gray-100 dark:border-slate-800" alt="Work sample" />
          ))}
        </div>
      </div>

      <div className="bg-gray-50 dark:bg-slate-900/50 px-5 py-3 border-t border-gray-100 dark:border-slate-800 flex items-center justify-between">
        {isUnlocked ? (
          <div className="flex items-center gap-2 text-green-600 dark:text-green-500 font-bold">
            <i className="fa-solid fa-phone"></i>
            <span className="text-sm">{fundi.phoneNumber}</span>
          </div>
        ) : (
          <div className="flex items-center gap-2 text-gray-400 dark:text-slate-600">
            <i className="fa-solid fa-lock"></i>
            <span className="text-xs uppercase font-bold tracking-tighter">{t.phoneHidden}</span>
          </div>
        )}

        {!isUnlocked && (
          <button 
            onClick={() => onUnlock(fundi.userId)}
            className="bg-yellow-500 hover:bg-yellow-600 text-slate-900 text-[10px] font-black px-4 py-2 rounded-lg transition-all flex items-center gap-2 shadow-sm"
          >
            {t.unlockContact} ({UNLOCK_FEE.toLocaleString()} {CURRENCY})
          </button>
        )}
        
        {isUnlocked && (
          <button className="text-blue-600 dark:text-blue-400 text-xs font-bold hover:underline bg-blue-50 dark:bg-blue-900/20 px-3 py-1.5 rounded-lg">
            Message
          </button>
        )}
      </div>
    </div>
  );
};

export default FundiCard;
