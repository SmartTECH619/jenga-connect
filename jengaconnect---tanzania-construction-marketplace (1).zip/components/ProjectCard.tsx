
import React from 'react';
import { Project } from '../types';
import { CURRENCY } from '../constants';
import { translations } from '../translations';

interface ProjectCardProps {
  project: Project;
  onApply?: (projectId: string) => void;
  onViewDetails?: (projectId: string) => void;
  canApply?: boolean;
  language: 'sw' | 'en';
}

const ProjectCard: React.FC<ProjectCardProps> = ({ project, onApply, onViewDetails, canApply, language }) => {
  const t = translations[language];

  return (
    <div className="bg-white dark:bg-slate-900 rounded-xl shadow-sm border border-gray-200 dark:border-slate-800 p-5 hover:shadow-md transition-all duration-300">
      <div className="flex justify-between items-start mb-4">
        <div className="min-w-0 flex-1">
          <span className="text-[10px] font-bold text-blue-600 dark:text-blue-400 bg-blue-50 dark:bg-blue-900/30 px-2 py-1 rounded uppercase mb-2 inline-block border border-blue-100 dark:border-blue-900/50">
            {project.type}
          </span>
          <h3 className="text-lg font-bold text-gray-900 dark:text-white line-clamp-1">{project.title}</h3>
        </div>
        <div className="text-right flex-shrink-0 ml-4">
          <p className="text-xl font-black text-gray-900 dark:text-white">{project.budget.toLocaleString()} <span className="text-xs font-medium text-gray-400">{CURRENCY}</span></p>
          <p className="text-[10px] text-gray-500 dark:text-slate-500 uppercase tracking-widest font-bold italic">{t.budget}</p>
        </div>
      </div>

      <div className="grid grid-cols-2 gap-y-3 mb-6 text-xs md:text-sm text-gray-600 dark:text-slate-400">
        <div className="flex items-center gap-2">
          <i className="fa-solid fa-location-dot text-gray-400 dark:text-slate-600"></i>
          <span className="truncate">{project.location}</span>
        </div>
        <div className="flex items-center gap-2">
          <i className="fa-solid fa-calendar text-gray-400 dark:text-slate-600"></i>
          <span>{t.deadline}: {new Date(project.deadline).toLocaleDateString()}</span>
        </div>
        <div className="flex items-center gap-2">
          <i className="fa-solid fa-clock text-gray-400 dark:text-slate-600"></i>
          <span>{project.duration}</span>
        </div>
        <div className="flex items-center gap-2">
          <i className="fa-solid fa-users text-gray-400 dark:text-slate-600"></i>
          <span>{project.applicants.length} {t.applications}</span>
        </div>
      </div>

      <div className="mb-6">
        <p className="text-[10px] text-gray-400 dark:text-slate-600 font-bold uppercase tracking-widest mb-2 italic">{t.requiredSkills}</p>
        <div className="flex flex-wrap gap-2">
          {project.requiredSkills.map((skill) => (
            <span key={skill} className="bg-gray-50 dark:bg-slate-800 text-gray-700 dark:text-slate-300 px-2 py-1 rounded-md text-[10px] font-bold border border-gray-200 dark:border-slate-700">
              {skill}
            </span>
          ))}
        </div>
      </div>

      <p className="text-sm text-gray-600 dark:text-slate-400 line-clamp-2 mb-6 border-l-2 border-yellow-500 pl-3">
        {project.description}
      </p>

      <div className="flex gap-3">
        {onViewDetails && (
          <button 
            onClick={() => onViewDetails(project.id)}
            className="flex-1 border border-gray-300 dark:border-slate-700 hover:bg-gray-50 dark:hover:bg-slate-800 text-gray-700 dark:text-slate-300 font-bold py-2.5 rounded-xl transition-all text-xs"
          >
            {t.details}
          </button>
        )}
        {canApply && onApply && (
          <button 
            onClick={() => onApply(project.id)}
            className="flex-1 bg-yellow-500 hover:bg-yellow-600 text-slate-900 font-black py-2.5 rounded-xl transition-all text-xs shadow-lg active:scale-95"
          >
            {t.applyNow}
          </button>
        )}
      </div>
    </div>
  );
};

export default ProjectCard;
