
import React from 'react';
import { UserRole } from '../types';
import { translations } from '../translations';

interface SidebarProps {
  role: UserRole;
  activeTab: string;
  setActiveTab: (tab: string) => void;
  userName: string;
  onLogout: () => void;
  isOpen: boolean;
  setIsOpen: (open: boolean) => void;
  isDarkMode: boolean;
  toggleDarkMode: () => void;
  language: 'sw' | 'en';
  setLanguage: (lang: 'sw' | 'en') => void;
}

const Sidebar: React.FC<SidebarProps> = ({ 
  role, 
  activeTab, 
  setActiveTab, 
  userName, 
  onLogout, 
  isOpen, 
  setIsOpen,
  isDarkMode,
  toggleDarkMode,
  language,
  setLanguage
}) => {
  const t = translations[language];

  const menuItems = [
    { id: 'dashboard', label: t.dashboard, icon: 'fa-gauge' },
    { id: 'projects', label: t.projects, icon: 'fa-briefcase' },
    { id: 'mafundi', label: t.mafundi, icon: 'fa-users', roles: [UserRole.BOSS, UserRole.ADMIN] },
    { id: 'applications', label: t.applications, icon: 'fa-file-lines' },
    { id: 'payments', label: t.payments, icon: 'fa-wallet' },
    { id: 'settings', label: t.settings, icon: 'fa-gear' },
  ];

  return (
    <>
      {/* Mobile Overlay */}
      {isOpen && (
        <div 
          className="fixed inset-0 bg-black/60 backdrop-blur-sm z-40 lg:hidden"
          onClick={() => setIsOpen(false)}
        ></div>
      )}

      <div className={`w-64 h-screen bg-slate-900 text-white flex flex-col fixed left-0 top-0 z-50 transition-transform duration-300 lg:translate-x-0 ${isOpen ? 'translate-x-0' : '-translate-x-full shadow-2xl lg:shadow-none border-r border-slate-800'}`}>
        {/* Logo Section - Fixed Header of Sidebar */}
        <div className="p-6 flex justify-between items-center flex-shrink-0">
          <div>
            <h1 className="text-2xl font-bold text-yellow-500">Jenga<span className="text-white">Connect</span></h1>
            <p className="text-[10px] text-slate-400 mt-1 uppercase tracking-widest font-semibold">{t.slogan}</p>
          </div>
          <button onClick={() => setIsOpen(false)} className="lg:hidden text-slate-400 p-2 hover:bg-slate-800 rounded-full">
            <i className="fa-solid fa-xmark text-xl"></i>
          </button>
        </div>

        {/* Scrollable Area */}
        <div className="flex-1 overflow-y-auto sidebar-scroll px-4 pb-4">
          {/* Control Section (Theme & Language) */}
          <div className="mb-6 space-y-2">
            <div className="flex items-center justify-between bg-slate-800/50 p-3 rounded-xl border border-slate-800">
              <span className="text-[10px] font-bold text-slate-400 uppercase tracking-widest">{t.language}</span>
              <div className="flex bg-slate-900 p-1 rounded-lg">
                <button 
                  onClick={() => setLanguage('sw')}
                  className={`px-2 py-1 text-[10px] font-bold rounded-md transition-all ${language === 'sw' ? 'bg-yellow-500 text-slate-900' : 'text-slate-500 hover:text-white'}`}
                >
                  SW
                </button>
                <button 
                  onClick={() => setLanguage('en')}
                  className={`px-2 py-1 text-[10px] font-bold rounded-md transition-all ${language === 'en' ? 'bg-yellow-500 text-slate-900' : 'text-slate-500 hover:text-white'}`}
                >
                  EN
                </button>
              </div>
            </div>

            <div className="flex items-center justify-between bg-slate-800/50 p-3 rounded-xl border border-slate-800">
              <span className="text-[10px] font-bold text-slate-400 uppercase tracking-widest">
                {isDarkMode ? 'Dark' : 'Light'}
              </span>
              <button 
                onClick={toggleDarkMode}
                className={`w-10 h-5 rounded-full transition-colors relative flex items-center px-1 ${isDarkMode ? 'bg-yellow-500' : 'bg-slate-600'}`}
              >
                <div className={`w-3.5 h-3.5 bg-white rounded-full shadow-md transition-transform duration-300 ${isDarkMode ? 'translate-x-4.5' : 'translate-x-0'}`}></div>
              </button>
            </div>
          </div>

          <nav className="space-y-1">
            {menuItems.map((item) => {
              if (item.roles && !item.roles.includes(role)) return null;
              return (
                <button
                  key={item.id}
                  onClick={() => {
                    setActiveTab(item.id);
                    setIsOpen(false);
                  }}
                  className={`w-full flex items-center gap-3 px-4 py-3 rounded-xl transition-all group ${
                    activeTab === item.id 
                      ? 'bg-yellow-500 text-slate-900 font-bold shadow-lg shadow-yellow-500/20' 
                      : 'text-slate-400 hover:bg-slate-800 hover:text-white'
                  }`}
                >
                  <i className={`fa-solid ${item.icon} w-5 transition-transform group-hover:scale-110`}></i>
                  <span className="text-sm">{item.label}</span>
                </button>
              );
            })}
          </nav>
        </div>

        {/* Footer Profile Section - Fixed */}
        <div className="p-4 border-t border-slate-800 bg-slate-900 flex-shrink-0">
          <div className="flex items-center gap-3 mb-4 p-2 rounded-xl hover:bg-slate-800/50 transition-colors overflow-hidden">
            <div className="w-10 h-10 rounded-full bg-yellow-500 text-slate-900 flex items-center justify-center text-lg font-black flex-shrink-0 shadow-sm">
              {userName.charAt(0)}
            </div>
            <div className="min-w-0">
              <p className="text-sm font-bold truncate dark:text-white">{userName}</p>
              <p className="text-[10px] text-slate-500 capitalize bg-slate-800 px-2 py-0.5 rounded-full inline-block mt-0.5">{role.toLowerCase()}</p>
            </div>
          </div>
          <button 
            onClick={onLogout}
            className="w-full flex items-center gap-3 px-4 py-2.5 text-red-400 hover:bg-red-500/10 rounded-xl transition-all border border-red-500/20 font-bold text-sm"
          >
            <i className="fa-solid fa-right-from-bracket"></i>
            <span>{t.logout}</span>
          </button>
        </div>
      </div>
    </>
  );
};

export default Sidebar;
