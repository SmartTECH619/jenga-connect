
import React from 'react';
import { SkillType, ProjectType } from './types';

export const REGIONS = [
  'Dar es Salaam', 'Arusha', 'Mwanza', 'Dodoma', 'Geita', 'Mbeya', 'Tanga', 'Morogoro', 'Kilimanjaro'
];

export const SKILL_OPTIONS: SkillType[] = [
  'Welder', 'Masonry', 'Fundi Chuma', 'Electrician', 'Plumber', 'Carpenter', 'Painter', 'Tile Setter'
];

export const PROJECT_TYPES: ProjectType[] = [
  'Warehouse', 'Storey Building', 'Factory', 'Residential', 'Renovation'
];

export const CURRENCY = 'TZS';

export const UNLOCK_FEE = 15000; // 15,000 TZS per contact unlock

export const getIconForSkill = (skill: SkillType) => {
  switch (skill) {
    case 'Electrician': return <i className="fa-solid fa-bolt text-yellow-500"></i>;
    case 'Plumber': return <i className="fa-solid fa-faucet text-blue-500"></i>;
    case 'Masonry': return <i className="fa-solid fa-trowel-bricks text-orange-600"></i>;
    case 'Welder': return <i className="fa-solid fa-mask-ventilator text-gray-700"></i>;
    case 'Painter': return <i className="fa-solid fa-paint-roller text-pink-500"></i>;
    case 'Carpenter': return <i className="fa-solid fa-hammer text-amber-800"></i>;
    default: return <i className="fa-solid fa-hard-hat text-gray-500"></i>;
  }
};
