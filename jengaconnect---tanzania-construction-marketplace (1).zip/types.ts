
export enum UserRole {
  BOSS = 'BOSS',
  FUNDI = 'FUNDI',
  ADMIN = 'ADMIN'
}

export type SkillType = 
  | 'Welder' 
  | 'Masonry' 
  | 'Fundi Chuma' 
  | 'Electrician' 
  | 'Plumber' 
  | 'Carpenter' 
  | 'Painter' 
  | 'Tile Setter';

export type ProjectType = 
  | 'Warehouse' 
  | 'Storey Building' 
  | 'Factory' 
  | 'Residential' 
  | 'Renovation';

export interface User {
  id: string;
  name: string;
  email: string;
  role: UserRole;
  avatar?: string;
  balance: number; // Wallet balance in TZS
}

export interface FundiProfile {
  userId: string;
  skill: SkillType;
  experienceYears: number;
  location: {
    region: string;
    district: string;
  };
  bio: string;
  portfolio: string[]; // Image URLs
  availability: 'Available' | 'Busy' | 'Offline';
  rating: number;
  reviewCount: number;
  isVerified: boolean;
  phoneNumber: string;
  unlockedBy: string[]; // List of Boss IDs who paid for this contact
}

export interface Project {
  id: string;
  title: string;
  type: ProjectType;
  requiredSkills: SkillType[];
  budget: number; // in TZS
  location: string;
  duration: string;
  description: string;
  deadline: string;
  ownerId: string;
  status: 'Open' | 'Closed' | 'Awarded';
  applicants: string[]; // Fundi IDs
}

export interface Application {
  id: string;
  projectId: string;
  fundiId: string;
  status: 'Pending' | 'Shortlisted' | 'Rejected' | 'Hired';
  coverLetter: string;
  createdAt: string;
}

export type TransactionStatus = 'Pending' | 'Confirmed' | 'Rejected';

export interface Transaction {
  id: string;
  userId: string;
  userName?: string;
  amount: number;
  type: 'Unlock' | 'Deposit';
  status: TransactionStatus;
  reference?: string; // M-Pesa/Tigo Pesa Ref
  fundiId?: string;
  timestamp: string;
}
