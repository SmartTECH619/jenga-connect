
import React, { useState, useEffect } from 'react';
import { User, UserRole, FundiProfile, Project, Application, Transaction, SkillType, TransactionStatus } from './types';
import { MOCK_USERS, MOCK_FUNDI_PROFILES, MOCK_PROJECTS, MOCK_APPLICATIONS } from './mockData';
import Sidebar from './components/Sidebar';
import FundiCard from './components/FundiCard';
import ProjectCard from './components/ProjectCard';
import { CURRENCY, SKILL_OPTIONS, PROJECT_TYPES, UNLOCK_FEE, REGIONS } from './constants';
import { getProjectOptimizationTips } from './geminiService';
import { translations } from './translations';

const App: React.FC = () => {
  // Auth State
  const [currentUser, setCurrentUser] = useState<User | null>(null);
  const [activeTab, setActiveTab] = useState('dashboard');
  const [authMode, setAuthMode] = useState<'login' | 'signup'>('login');
  const [isLoggingIn, setIsLoggingIn] = useState(true);
  const [isSidebarOpen, setIsSidebarOpen] = useState(false);
  
  // Registration State
  const [regRole, setRegRole] = useState<UserRole>(UserRole.BOSS);

  // Language State
  const [language, setLanguage] = useState<'sw' | 'en'>(() => {
    const saved = localStorage.getItem('lang');
    return (saved as 'sw' | 'en') || 'sw';
  });

  useEffect(() => {
    localStorage.setItem('lang', language);
  }, [language]);

  const t = translations[language];

  // Dark Mode State
  const [isDarkMode, setIsDarkMode] = useState(() => {
    const saved = localStorage.getItem('theme');
    return saved === 'dark';
  });

  useEffect(() => {
    if (isDarkMode) {
      document.documentElement.classList.add('dark');
      localStorage.setItem('theme', 'dark');
    } else {
      document.documentElement.classList.remove('dark');
      localStorage.setItem('theme', 'light');
    }
  }, [isDarkMode]);

  const toggleDarkMode = () => setIsDarkMode(!isDarkMode);

  // App Data State
  const [users, setUsers] = useState<User[]>(MOCK_USERS);
  const [projects, setProjects] = useState<Project[]>(MOCK_PROJECTS);
  const [fundiProfiles, setFundiProfiles] = useState<FundiProfile[]>(MOCK_FUNDI_PROFILES);
  const [applications, setApplications] = useState<Application[]>(MOCK_APPLICATIONS);
  const [transactions, setTransactions] = useState<Transaction[]>([]);

  // UI State
  const [showPaymentModal, setShowPaymentModal] = useState<{ fundiId: string } | null>(null);
  const [showTopUpModal, setShowTopUpModal] = useState(false);
  const [topUpMethod, setTopUpMethod] = useState<'online' | 'manual'>('online');
  const [isProcessingPayment, setIsProcessingPayment] = useState(false);
  const [showProjectForm, setShowProjectForm] = useState(false);

  // Filtering
  const [fundiFilter, setFundiFilter] = useState<SkillType | 'All'>('All');

  const handleLogin = (user: User) => {
    setCurrentUser(user);
    setIsLoggingIn(false);
  };

  const handleLogout = () => {
    setCurrentUser(null);
    setIsLoggingIn(true);
    setAuthMode('login');
    setActiveTab('dashboard');
    setIsSidebarOpen(false);
  };

  const handleSignUp = (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    const formData = new FormData(e.currentTarget);
    
    const newUser: User = {
      id: `u-${Date.now()}`,
      name: formData.get('name') as string,
      email: formData.get('email') as string,
      role: regRole,
      avatar: `https://picsum.photos/seed/${Date.now()}/100`,
      balance: 0
    };

    setUsers(prev => [...prev, newUser]);

    if (regRole === UserRole.FUNDI) {
      const newProfile: FundiProfile = {
        userId: newUser.id,
        skill: formData.get('skill') as SkillType,
        experienceYears: parseInt(formData.get('experience') as string),
        location: {
          region: formData.get('region') as string,
          district: formData.get('district') as string,
        },
        bio: formData.get('bio') as string,
        portfolio: ['https://picsum.photos/seed/work_new1/400/300'],
        availability: 'Available',
        rating: 0,
        reviewCount: 0,
        isVerified: false,
        phoneNumber: formData.get('phone') as string,
        unlockedBy: []
      };
      setFundiProfiles(prev => [...prev, newProfile]);
    }

    handleLogin(newUser);
  };

  const handleOnlinePaymentSubmit = (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    if (!currentUser) return;
    const formData = new FormData(e.currentTarget);
    const amount = parseInt(formData.get('amount') as string);
    const provider = formData.get('provider') as string;

    setIsProcessingPayment(true);
    setTimeout(() => {
      const newTx: Transaction = {
        id: `tx-${Date.now()}`,
        userId: currentUser.id,
        userName: currentUser.name,
        amount,
        type: 'Deposit',
        status: 'Confirmed',
        reference: `ONLINE-${provider}-${Date.now().toString().slice(-6)}`,
        timestamp: new Date().toISOString()
      };
      setTransactions(prev => [newTx, ...prev]);
      setUsers(prev => prev.map(u => u.id === currentUser.id ? { ...u, balance: u.balance + amount } : u));
      setCurrentUser(prev => prev ? { ...prev, balance: prev.balance + amount } : null);
      setIsProcessingPayment(false);
      setShowTopUpModal(false);
      alert(t.paymentSuccess);
    }, 4000);
  };

  const handleManualDepositSubmit = (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    if (!currentUser) return;
    const formData = new FormData(e.currentTarget);
    const amount = parseInt(formData.get('amount') as string);
    const ref = formData.get('reference') as string;
    const newTx: Transaction = {
      id: `tx-${Date.now()}`,
      userId: currentUser.id,
      userName: currentUser.name,
      amount,
      type: 'Deposit',
      status: 'Pending',
      reference: ref,
      timestamp: new Date().toISOString()
    };
    setTransactions(prev => [newTx, ...prev]);
    setShowTopUpModal(false);
    alert(language === 'sw' ? 'Muamala umezalishwa! Admin atahakiki hivi punde.' : 'Transaction created! Admin will verify soon.');
  };

  const handleApproveTransaction = (txId: string) => {
    const tx = transactions.find(t => t.id === txId);
    if (!tx) return;
    setTransactions(prev => prev.map(t => t.id === txId ? { ...t, status: 'Confirmed' } : t));
    if (tx.type === 'Deposit') {
      setUsers(prev => prev.map(u => u.id === tx.userId ? { ...u, balance: u.balance + tx.amount } : u));
      if (currentUser?.id === tx.userId) {
        setCurrentUser(prev => prev ? { ...prev, balance: prev.balance + tx.amount } : null);
      }
    }
  };

  const handleRejectTransaction = (txId: string) => {
    setTransactions(prev => prev.map(t => t.id === txId ? { ...t, status: 'Rejected' } : t));
  };

  const handleUnlockContact = (fundiId: string) => {
    if (!currentUser) return;
    if (currentUser.balance < UNLOCK_FEE) {
      alert(t.insufficientBalance);
      setActiveTab('payments');
      return;
    }
    setShowPaymentModal({ fundiId });
  };

  const confirmUnlockPayment = () => {
    if (!currentUser || !showPaymentModal || currentUser.balance < UNLOCK_FEE) return;
    setUsers(prev => prev.map(u => u.id === currentUser.id ? { ...u, balance: u.balance - UNLOCK_FEE } : u));
    setCurrentUser(prev => prev ? { ...prev, balance: prev.balance - UNLOCK_FEE } : null);
    setFundiProfiles(prev => prev.map(p => p.userId === showPaymentModal.fundiId ? { ...p, unlockedBy: [...p.unlockedBy, currentUser.id] } : p));
    const newTx: Transaction = {
      id: `tx-${Date.now()}`,
      userId: currentUser.id,
      userName: currentUser.name,
      amount: UNLOCK_FEE,
      type: 'Unlock',
      status: 'Confirmed',
      fundiId: showPaymentModal.fundiId,
      timestamp: new Date().toISOString()
    };
    setTransactions(prev => [newTx, ...prev]);
    setShowPaymentModal(null);
  };

  const filteredFundi = fundiProfiles.filter(f => fundiFilter === 'All' || f.skill === fundiFilter);
  const availableProjects = projects.filter(p => p.status === 'Open');

  if (isLoggingIn) {
    return (
      <div className="min-h-screen flex items-center justify-center p-4 bg-transparent">
        <div className="bg-white/95 dark:bg-slate-900/98 glass-panel backdrop-blur-xl rounded-[2.5rem] shadow-2xl max-w-lg w-full p-8 md:p-12 animate-in fade-in zoom-in duration-500 overflow-hidden relative border border-white/40 dark:border-slate-800/50">
          <div className="absolute top-6 right-6 flex gap-2">
            <button onClick={() => setLanguage('sw')} className={`px-3 py-1 text-[10px] font-bold rounded-full transition-all ${language === 'sw' ? 'bg-yellow-500 text-white shadow-lg' : 'bg-slate-100 text-slate-400'}`}>SW</button>
            <button onClick={() => setLanguage('en')} className={`px-3 py-1 text-[10px] font-bold rounded-full transition-all ${language === 'en' ? 'bg-yellow-500 text-white shadow-lg' : 'bg-slate-100 text-slate-400'}`}>EN</button>
          </div>
          <div className="text-center mb-10">
            <div className="inline-block p-4 bg-yellow-500 rounded-3xl mb-4 shadow-xl shadow-yellow-500/30">
              <i className="fa-solid fa-helmet-safety text-3xl text-white"></i>
            </div>
            <h1 className="text-4xl font-black text-slate-900 dark:text-white tracking-tighter">Jenga<span className="text-yellow-500">Connect</span></h1>
            <p className="text-slate-500 dark:text-slate-400 mt-2 font-medium tracking-wide">{t.slogan}</p>
          </div>
          {authMode === 'login' ? (
            <div className="space-y-6">
              <p className="text-[10px] font-black text-slate-400 uppercase tracking-widest text-center mb-2">{t.loginAs}</p>
              <div className="space-y-4 max-h-[400px] overflow-y-auto no-scrollbar pr-1">
                {users.map(user => (
                  <button key={user.id} onClick={() => handleLogin(user)} className="w-full flex items-center gap-5 p-5 bg-white/50 dark:bg-slate-800/50 border border-slate-100 dark:border-slate-800 rounded-[1.5rem] hover:bg-white dark:hover:bg-slate-800 hover:border-yellow-500 dark:hover:border-yellow-500/50 transition-all text-left shadow-sm group">
                    <div className="relative">
                      <img src={user.avatar} className="w-14 h-14 rounded-2xl border-2 border-white dark:border-slate-700 shadow-md group-hover:scale-105 transition-transform" alt="" />
                      <div className="absolute -bottom-1 -right-1 w-4 h-4 bg-green-500 border-2 border-white dark:border-slate-800 rounded-full"></div>
                    </div>
                    <div className="flex-1">
                      <h3 className="font-bold text-slate-900 dark:text-white text-lg">{user.name}</h3>
                      <p className="text-[10px] text-white bg-slate-900/80 dark:bg-yellow-500/90 px-3 py-0.5 rounded-full inline-block uppercase mt-1 font-black tracking-wider">{user.role}</p>
                    </div>
                    <i className="fa-solid fa-chevron-right text-slate-300 group-hover:text-yellow-500 transition-colors"></i>
                  </button>
                ))}
              </div>
              <button onClick={() => setAuthMode('signup')} className="w-full text-center text-xs font-bold text-blue-600 dark:text-blue-400 hover:underline">{t.signUp}</button>
            </div>
          ) : (
            <div className="space-y-6 animate-in slide-in-from-right duration-300">
               <div className="flex p-1.5 bg-slate-100 dark:bg-slate-800 rounded-2xl mb-6">
                <button onClick={() => setRegRole(UserRole.BOSS)} className={`flex-1 py-3 text-sm font-black rounded-xl transition-all ${regRole === UserRole.BOSS ? 'bg-white dark:bg-slate-700 shadow-lg text-slate-900 dark:text-white' : 'text-slate-500'}`}>{t.imBoss}</button>
                <button onClick={() => setRegRole(UserRole.FUNDI)} className={`flex-1 py-3 text-sm font-black rounded-xl transition-all ${regRole === UserRole.FUNDI ? 'bg-white dark:bg-slate-700 shadow-lg text-slate-900 dark:text-white' : 'text-slate-500'}`}>{t.imFundi}</button>
              </div>
              <form onSubmit={handleSignUp} className="space-y-5">
                <div className="relative">
                  <i className="fa-solid fa-user absolute left-4 top-1/2 -translate-y-1/2 text-slate-400"></i>
                  <input name="name" placeholder={t.fullName} required className="w-full p-4 pl-12 bg-slate-50 dark:bg-slate-800/80 border border-slate-200 dark:border-slate-700 rounded-2xl outline-none text-slate-900 dark:text-white focus:border-yellow-500 transition-colors" />
                </div>
                <div className="relative">
                  <i className="fa-solid fa-envelope absolute left-4 top-1/2 -translate-y-1/2 text-slate-400"></i>
                  <input name="email" type="email" placeholder={t.email} required className="w-full p-4 pl-12 bg-slate-50 dark:bg-slate-800/80 border border-slate-200 dark:border-slate-700 rounded-2xl outline-none text-slate-900 dark:text-white focus:border-yellow-500 transition-colors" />
                </div>
                <button type="submit" className="w-full bg-slate-900 dark:bg-yellow-500 dark:text-slate-900 text-white font-black py-4 rounded-2xl shadow-xl hover:scale-[1.02] active:scale-[0.98] transition-all text-lg tracking-tight">{t.completeRegistration}</button>
              </form>
              <button onClick={() => setAuthMode('login')} className="w-full text-center text-xs font-bold text-slate-600 dark:text-slate-400 hover:underline">{t.alreadyHaveAccount}</button>
            </div>
          )}
        </div>
      </div>
    );
  }

  return (
    <div className="flex min-h-screen transition-colors duration-300 bg-transparent">
      <Sidebar 
        role={currentUser!.role} 
        activeTab={activeTab} 
        setActiveTab={setActiveTab} 
        userName={currentUser!.name}
        onLogout={handleLogout}
        isOpen={isSidebarOpen}
        setIsOpen={setIsSidebarOpen}
        isDarkMode={isDarkMode}
        toggleDarkMode={toggleDarkMode}
        language={language}
        setLanguage={setLanguage}
      />

      <main className="flex-1 lg:ml-64 p-4 md:p-10">
        {/* Header Section */}
        <div className="flex justify-between items-center mb-10 p-5 bg-white/40 dark:bg-slate-900/40 glass-panel rounded-3xl border border-white/40 dark:border-slate-800/40">
          <div className="flex items-center gap-5">
            <button onClick={() => setIsSidebarOpen(true)} className="lg:hidden w-12 h-12 flex items-center justify-center bg-slate-900 text-white rounded-2xl shadow-xl">
              <i className="fa-solid fa-bars"></i>
            </button>
            <div>
              <h2 className="text-2xl md:text-3xl font-black dark:text-white tracking-tight">{t.welcome}, {currentUser?.name.split(' ')[0]}!</h2>
              <p className="text-xs text-slate-500 dark:text-slate-400 font-bold uppercase tracking-widest mt-0.5">{t.slogan}</p>
            </div>
          </div>
          <div className="flex items-center gap-4">
            <div className={`px-5 py-3 rounded-2xl border flex items-center gap-3 shadow-xl transition-all ${isDarkMode ? 'bg-slate-900/90 border-slate-800 text-white' : 'bg-white/90 border-slate-200 text-slate-900'}`}>
              <div className="w-8 h-8 bg-yellow-500 rounded-full flex items-center justify-center text-white text-xs">
                <i className="fa-solid fa-wallet"></i>
              </div>
              <div>
                <p className="text-[8px] font-black text-slate-400 uppercase tracking-tighter">{t.wallet}</p>
                <span className="font-black text-lg">{currentUser?.balance.toLocaleString()} <span className="text-[10px] font-medium">{CURRENCY}</span></span>
              </div>
            </div>
          </div>
        </div>

        {/* Dynamic Content */}
        <div className="animate-in fade-in slide-in-from-bottom-4 duration-500">
          {activeTab === 'dashboard' && (
            <div className="space-y-10">
               <div className="grid grid-cols-2 md:grid-cols-4 gap-4 md:gap-8">
                {[
                  { label: t.activeProjects, val: projects.filter(p => p.status === 'Open').length, icon: 'fa-building', color: 'text-blue-500', bg: 'bg-blue-500/10' },
                  { label: t.totalMafundi, val: fundiProfiles.length, icon: 'fa-user-gear', color: 'text-emerald-500', bg: 'bg-emerald-500/10' },
                  { label: t.applications, val: applications.length, icon: 'fa-file-signature', color: 'text-indigo-500', bg: 'bg-indigo-500/10' },
                  { label: t.wallet, val: currentUser?.balance.toLocaleString(), icon: 'fa-coins', color: 'text-amber-500', bg: 'bg-amber-500/10' },
                ].map((stat, i) => (
                  <div key={i} className={`p-6 md:p-8 rounded-[2rem] shadow-xl border glass-panel transition-transform hover:scale-[1.02] ${isDarkMode ? 'bg-slate-900/80 border-slate-800' : 'bg-white/80 border-white'}`}>
                    <div className={`w-14 h-14 ${stat.bg} ${stat.color} rounded-2xl flex items-center justify-center mb-6 text-2xl shadow-inner`}><i className={`fa-solid ${stat.icon}`}></i></div>
                    <h3 className="text-[10px] uppercase font-black text-slate-400 dark:text-slate-500 tracking-widest">{stat.label}</h3>
                    <p className="text-2xl md:text-3xl font-black mt-2 dark:text-white tabular-nums">{stat.val}</p>
                  </div>
                ))}
              </div>
              
              <div className="grid grid-cols-1 lg:grid-cols-2 gap-10">
                 <div className={`p-8 rounded-[2.5rem] border glass-panel shadow-2xl ${isDarkMode ? 'bg-slate-900/80 border-slate-800' : 'bg-white/80 border-white'}`}>
                  <div className="flex justify-between items-center mb-8">
                    <h3 className="text-xl font-black flex items-center gap-3 dark:text-white">
                      <div className="w-10 h-10 bg-yellow-500 rounded-xl flex items-center justify-center text-white"><i className="fa-solid fa-star"></i></div>
                      {t.featuredMafundi}
                    </h3>
                  </div>
                  <div className="space-y-5">
                    {fundiProfiles.slice(0, 3).map(f => (
                      <div key={f.userId} className="flex items-center gap-5 p-4 rounded-2xl bg-white/40 dark:bg-slate-800/40 hover:bg-white dark:hover:bg-slate-800 transition-all border border-transparent hover:border-yellow-500/30">
                        <img src={users.find(u => u.id === f.userId)?.avatar} className="w-16 h-16 rounded-2xl object-cover shadow-lg" alt="" />
                        <div className="flex-1">
                          <p className="font-bold text-lg dark:text-white">{users.find(u => u.id === f.userId)?.name}</p>
                          <p className="text-xs font-semibold text-slate-500 uppercase tracking-wide">{f.skill}</p>
                        </div>
                        <div className="flex items-center gap-1.5 bg-yellow-500/10 text-yellow-600 dark:text-yellow-500 px-3 py-1.5 rounded-full font-black text-sm">
                          <i className="fa-solid fa-star"></i>
                          <span>{f.rating}</span>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>

                <div className={`p-8 rounded-[2.5rem] border glass-panel shadow-2xl ${isDarkMode ? 'bg-slate-900/80 border-slate-800' : 'bg-white/80 border-white'}`}>
                  <h3 className="text-xl font-black mb-8 dark:text-white flex items-center gap-3">
                    <div className="w-10 h-10 bg-blue-500 rounded-xl flex items-center justify-center text-white"><i className="fa-solid fa-briefcase"></i></div>
                    {t.latestTenders}
                  </h3>
                  <div className="space-y-5">
                    {projects.slice(0, 3).map(p => (
                      <div key={p.id} className="p-5 rounded-2xl bg-white/40 dark:bg-slate-800/40 border border-transparent hover:border-blue-500/30 transition-all">
                        <p className="text-lg font-bold dark:text-white truncate">{p.title}</p>
                        <div className="flex items-center gap-4 mt-2">
                          <p className="text-xs font-bold text-slate-500"><i className="fa-solid fa-location-dot mr-1.5"></i>{p.location}</p>
                          <p className="text-xs font-black text-blue-600 dark:text-blue-400">{p.budget.toLocaleString()} {CURRENCY}</p>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              </div>
            </div>
          )}

          {activeTab === 'mafundi' && (
            <div className="space-y-10">
               <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-6 p-8 bg-white/40 dark:bg-slate-900/40 glass-panel rounded-[2rem] border border-white/40 dark:border-slate-800/40">
                <div>
                  <h3 className="text-2xl font-black dark:text-white">{t.mafundi} Tanzania</h3>
                  <p className="text-sm text-slate-500 dark:text-slate-400 mt-1">Gundua mafundi mahiri waliohakikiwa nchi nzima.</p>
                </div>
                <select className={`w-full md:w-auto border-2 font-bold text-sm rounded-2xl px-6 py-4 shadow-xl outline-none focus:border-yellow-500 transition-all appearance-none cursor-pointer ${isDarkMode ? 'bg-slate-900 border-slate-800 text-slate-100' : 'bg-white border-slate-100 text-slate-900'}`} value={fundiFilter} onChange={(e) => setFundiFilter(e.target.value as any)}>
                  <option value="All">{t.searchSkills}</option>
                  {SKILL_OPTIONS.map(s => <option key={s} value={s}>{s}</option>)}
                </select>
              </div>
              <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-8">
                {filteredFundi.map(fundi => (
                  <FundiCard key={fundi.userId} fundi={fundi} user={users.find(u => u.id === fundi.userId)!} isUnlocked={fundi.unlockedBy.includes(currentUser?.id || '')} onUnlock={handleUnlockContact} language={language} />
                ))}
              </div>
            </div>
          )}

          {activeTab === 'payments' && (
            <div className="space-y-10">
               <h3 className="text-2xl font-black dark:text-white">{t.wallet}</h3>
              <div className="grid grid-cols-1 lg:grid-cols-3 gap-10">
                <div className={`rounded-[2.5rem] shadow-2xl border p-12 flex flex-col items-center col-span-1 glass-panel transition-transform hover:scale-[1.01] ${isDarkMode ? 'bg-slate-900/80 border-slate-800' : 'bg-white/80 border-white'}`}>
                  <div className="w-20 h-20 bg-yellow-500 rounded-3xl flex items-center justify-center text-white text-3xl mb-8 shadow-xl shadow-yellow-500/40">
                    <i className="fa-solid fa-piggy-bank"></i>
                  </div>
                  <p className="text-slate-500 dark:text-slate-400 font-bold uppercase tracking-widest text-sm">{t.totalSpentLabel}</p>
                  <h2 className="text-5xl font-black my-8 dark:text-white tracking-tighter tabular-nums">{currentUser?.balance.toLocaleString()} <span className="text-xl font-medium">{CURRENCY}</span></h2>
                  {currentUser?.role === UserRole.BOSS && (
                    <button onClick={() => setShowTopUpModal(true)} className="w-full bg-slate-900 dark:bg-yellow-500 dark:text-slate-900 text-white py-5 rounded-2xl font-black shadow-xl hover:opacity-90 transition-all transform active:scale-95 text-lg">
                      <i className="fa-solid fa-plus mr-3"></i> {t.topUp}
                    </button>
                  )}
                </div>

                <div className={`rounded-[2.5rem] shadow-2xl border col-span-1 lg:col-span-2 overflow-hidden glass-panel ${isDarkMode ? 'bg-slate-900/80 border-slate-800' : 'bg-white/80 border-white'}`}>
                  <div className={`p-8 border-b ${isDarkMode ? 'bg-slate-800/50 border-slate-800' : 'bg-slate-50/50 border-slate-100'}`}>
                    <h4 className="font-black text-lg dark:text-white uppercase tracking-tight">{currentUser?.role === UserRole.ADMIN ? t.pendingApprovals : t.history}</h4>
                  </div>
                  <div className="divide-y dark:divide-slate-800">
                    {transactions
                      .filter(tx => currentUser?.role === UserRole.ADMIN || tx.userId === currentUser?.id)
                      .map(tx => (
                        <div key={tx.id} className="p-6 flex flex-col md:flex-row md:items-center justify-between gap-6 hover:bg-white/20 dark:hover:bg-slate-800/20 transition-all">
                          <div className="flex items-center gap-6">
                             <div className={`w-14 h-14 rounded-2xl flex items-center justify-center text-2xl shadow-inner ${
                              tx.type === 'Deposit' ? 'bg-green-100 text-green-600 dark:bg-green-900/30' : 'bg-blue-100 text-blue-600 dark:bg-blue-900/30'
                            }`}>
                              <i className={`fa-solid ${tx.type === 'Deposit' ? 'fa-circle-arrow-down' : 'fa-unlock'}`}></i>
                            </div>
                            <div>
                              <p className="text-lg font-bold dark:text-white">{tx.type === 'Deposit' ? `${t.topUp} (${tx.userName})` : `${t.unlockContact}`}</p>
                              <p className="text-xs font-semibold text-slate-500 mt-0.5">{new Date(tx.timestamp).toLocaleString()} • {tx.reference || 'Wallet Spend'}</p>
                            </div>
                          </div>
                          <div className="flex items-center gap-6 justify-between md:justify-end">
                             <p className={`text-xl font-black tabular-nums ${tx.type === 'Deposit' ? 'text-emerald-500' : 'text-red-500'}`}>
                              {tx.type === 'Deposit' ? '+' : '-'}{tx.amount.toLocaleString()}
                            </p>
                            <span className={`text-[10px] font-black px-4 py-1.5 rounded-full uppercase tracking-widest ${
                              tx.status === 'Pending' ? 'bg-yellow-100 text-yellow-700 dark:bg-yellow-900/30' :
                              tx.status === 'Confirmed' ? 'bg-green-100 text-green-700 dark:bg-green-900/30' : 'bg-red-100 text-red-700 dark:bg-red-900/30'
                            }`}>
                              {tx.status}
                            </span>
                          </div>
                        </div>
                    ))}
                    {transactions.length === 0 && <div className="p-20 text-center text-slate-400 font-bold italic tracking-wide">Hakuna muamala wowote hapa.</div>}
                  </div>
                </div>
              </div>
            </div>
          )}
        </div>
      </main>

      {/* Top Up Modal */}
      {showTopUpModal && (
        <div className="fixed inset-0 bg-black/80 backdrop-blur-md z-[100] flex items-center justify-center p-4 animate-in fade-in duration-300">
          <div className={`rounded-[2.5rem] max-w-md w-full p-10 shadow-3xl overflow-hidden relative border ${isDarkMode ? 'bg-slate-900 border-slate-800' : 'bg-white border-slate-100'}`}>
            {isProcessingPayment ? (
              <div className="text-center py-16 animate-in zoom-in duration-300">
                <div className="w-20 h-20 border-8 border-yellow-500 border-t-transparent rounded-full animate-spin mx-auto mb-10 shadow-lg shadow-yellow-500/20"></div>
                <h3 className="text-2xl font-black mb-4 dark:text-white tracking-tight">{t.processingPayment}</h3>
                <p className="text-sm text-slate-500 dark:text-slate-400 px-8 font-medium leading-relaxed">{t.finishOnPhone}</p>
              </div>
            ) : (
              <>
                <h3 className="text-3xl font-black mb-8 dark:text-white tracking-tighter">{t.topUp}</h3>
                <div className="flex p-1.5 bg-slate-100 dark:bg-slate-800 rounded-2xl mb-8 shadow-inner">
                  <button onClick={() => setTopUpMethod('online')} className={`flex-1 py-3 text-[10px] font-black rounded-xl transition-all uppercase tracking-widest ${topUpMethod === 'online' ? 'bg-white dark:bg-slate-700 shadow-xl dark:text-white text-slate-900' : 'text-slate-500'}`}>
                    <i className="fa-solid fa-bolt mr-2 text-yellow-500"></i> {t.onlineLipa}
                  </button>
                  <button onClick={() => setTopUpMethod('manual')} className={`flex-1 py-3 text-[10px] font-black rounded-xl transition-all uppercase tracking-widest ${topUpMethod === 'manual' ? 'bg-white dark:bg-slate-700 shadow-xl dark:text-white text-slate-900' : 'text-slate-500'}`}>
                    <i className="fa-solid fa-file-invoice mr-2"></i> {t.manualLipa}
                  </button>
                </div>
                {topUpMethod === 'online' ? (
                  <form onSubmit={handleOnlinePaymentSubmit} className="space-y-6">
                    <div className="grid grid-cols-3 gap-3">
                      {['M-Pesa', 'TigoPesa', 'Airtel'].map(prov => (
                        <label key={prov} className="relative cursor-pointer">
                          <input type="radio" name="provider" value={prov} className="peer sr-only" required />
                          <div className="p-4 border-2 rounded-2xl text-center text-[10px] font-black peer-checked:border-yellow-500 peer-checked:bg-yellow-500/10 peer-checked:text-yellow-600 border-slate-100 dark:border-slate-800 transition-all hover:bg-slate-50 dark:hover:bg-slate-800 uppercase tracking-tighter">
                            {prov}
                          </div>
                        </label>
                      ))}
                    </div>
                    <div className="space-y-4">
                      <input name="phone" placeholder={t.phone} required className="w-full p-5 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-2xl outline-none text-slate-900 dark:text-white focus:border-yellow-500 transition-colors font-bold" />
                      <input name="amount" type="number" placeholder={t.amount} required className="w-full p-5 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-2xl outline-none text-slate-900 dark:text-white focus:border-yellow-500 transition-colors font-bold" />
                    </div>
                    <button type="submit" className="w-full bg-slate-900 dark:bg-yellow-500 dark:text-slate-900 text-white font-black py-5 rounded-2xl shadow-2xl hover:scale-[1.02] active:scale-[0.98] transition-all text-lg">{t.onlineLipa}</button>
                  </form>
                ) : (
                  <form onSubmit={handleManualDepositSubmit} className="space-y-6">
                     <p className="text-xs text-slate-500 dark:text-slate-400 mb-6 bg-yellow-500/10 p-5 rounded-2xl border border-yellow-500/20 font-medium leading-relaxed italic">{t.depositInstructions}</p>
                     <input name="amount" type="number" placeholder={t.amount} required className="w-full p-5 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-2xl outline-none text-slate-900 dark:text-white font-bold" />
                     <input name="reference" placeholder={t.refNumber} required className="w-full p-5 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-2xl outline-none text-slate-900 dark:text-white font-bold" />
                     <button type="submit" className="w-full bg-slate-900 dark:bg-yellow-500 dark:text-slate-900 text-white font-black py-5 rounded-2xl shadow-2xl">{t.manualLipa}</button>
                  </form>
                )}
                <button onClick={() => setShowTopUpModal(false)} className="w-full mt-6 py-2 font-black text-slate-400 text-xs uppercase tracking-widest hover:text-slate-600 dark:hover:text-slate-200 transition-colors">{t.cancel}</button>
              </>
            )}
          </div>
        </div>
      )}

      {/* Unlock Confirm Modal */}
      {showPaymentModal && (
        <div className="fixed inset-0 bg-black/80 backdrop-blur-md z-[100] flex items-center justify-center p-4 animate-in fade-in zoom-in duration-300">
          <div className={`rounded-[2.5rem] max-w-sm w-full p-10 text-center shadow-3xl border ${isDarkMode ? 'bg-slate-900 text-slate-100 border-slate-800' : 'bg-white text-gray-900 border-slate-100'}`}>
            <div className="w-24 h-24 bg-yellow-500 rounded-3xl flex items-center justify-center text-white text-4xl mx-auto mb-8 shadow-xl shadow-yellow-500/40">
              <i className="fa-solid fa-key"></i>
            </div>
            <h3 className="text-3xl font-black mb-4 tracking-tighter">{t.unlockContact}</h3>
            <p className="mb-10 text-sm text-slate-500 dark:text-slate-400 font-medium leading-relaxed">{t.confirmPayment} <span className="font-black text-slate-900 dark:text-white">{UNLOCK_FEE.toLocaleString()} {CURRENCY}</span>.</p>
            <div className="space-y-4">
              <button onClick={confirmUnlockPayment} className="w-full bg-slate-900 dark:bg-yellow-500 dark:text-slate-900 text-white font-black py-5 rounded-2xl shadow-2xl hover:scale-[1.02] active:scale-[0.98] transition-all text-lg">{t.payMobile}</button>
              <button onClick={() => setShowPaymentModal(null)} className="w-full font-black py-2 text-slate-400 text-xs uppercase tracking-widest hover:text-slate-600 transition-colors">{t.cancel}</button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default App;
