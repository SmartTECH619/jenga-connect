
import { User, UserRole, FundiProfile, Project, Application } from './types';

export const MOCK_USERS: User[] = [
  // Added missing balance property for each user to match User interface
  { id: 'u1', name: 'Mzee Bakari', email: 'bakari@boss.com', role: UserRole.BOSS, avatar: 'https://picsum.photos/seed/bakari/100', balance: 50000 },
  { id: 'u2', name: 'Suleiman Fundi', email: 'sule@fundi.com', role: UserRole.FUNDI, avatar: 'https://picsum.photos/seed/sule/100', balance: 0 },
  { id: 'u3', name: 'Asha Welding', email: 'asha@fundi.com', role: UserRole.FUNDI, avatar: 'https://picsum.photos/seed/asha/100', balance: 0 },
  { id: 'u4', name: 'Platform Admin', email: 'admin@jengaconnect.co.tz', role: UserRole.ADMIN, avatar: 'https://picsum.photos/seed/admin/100', balance: 0 },
];

export const MOCK_FUNDI_PROFILES: FundiProfile[] = [
  {
    userId: 'u2',
    skill: 'Electrician',
    experienceYears: 8,
    location: { region: 'Dar es Salaam', district: 'Kinondoni' },
    bio: 'Experienced industrial electrician with a focus on warehouse solar installations and complex wiring.',
    portfolio: ['https://picsum.photos/seed/work1/400/300', 'https://picsum.photos/seed/work2/400/300'],
    availability: 'Available',
    rating: 4.8,
    reviewCount: 24,
    isVerified: true,
    phoneNumber: '+255 712 345 678',
    unlockedBy: []
  },
  {
    userId: 'u3',
    skill: 'Welder',
    experienceYears: 12,
    location: { region: 'Geita', district: 'Geita Town' },
    bio: 'Specialist in heavy metal structures for mining and factories. Certified ARC and TIG welder.',
    portfolio: ['https://picsum.photos/seed/work3/400/300', 'https://picsum.photos/seed/work4/400/300'],
    availability: 'Busy',
    rating: 4.9,
    reviewCount: 45,
    isVerified: true,
    phoneNumber: '+255 788 990 011',
    unlockedBy: ['u1']
  }
];

export const MOCK_PROJECTS: Project[] = [
  {
    id: 'p1',
    title: 'Warehouse Roof Construction - Geita',
    type: 'Warehouse',
    requiredSkills: ['Welder', 'Fundi Chuma'],
    budget: 4500000,
    location: 'Geita Region',
    duration: '3 Weeks',
    description: 'We need a team of expert welders to assemble the steel truss system for a new 1000sqm warehouse.',
    deadline: '2024-06-15',
    ownerId: 'u1',
    status: 'Open',
    applicants: ['u3']
  },
  {
    id: 'p2',
    title: 'Modern Apartment Complex - Oysterbay',
    type: 'Storey Building',
    requiredSkills: ['Masonry', 'Electrician', 'Plumber'],
    budget: 85000000,
    location: 'Dar es Salaam',
    duration: '12 Months',
    description: 'Large scale project requiring multiple skilled mafundi for the finishing stages of a 5-storey luxury apartment.',
    deadline: '2024-08-01',
    ownerId: 'u1',
    status: 'Open',
    applicants: ['u2']
  }
];

export const MOCK_APPLICATIONS: Application[] = [
  {
    id: 'a1',
    projectId: 'p1',
    fundiId: 'u3',
    status: 'Pending',
    coverLetter: 'I have extensive experience with steel trusses in Geita. I have my own equipment.',
    createdAt: new Date().toISOString()
  }
];
